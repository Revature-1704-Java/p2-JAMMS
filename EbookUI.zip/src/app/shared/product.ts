export interface Product {
    id: number;
    title: string;
    author: string;
    published: number;
    price: number;
}